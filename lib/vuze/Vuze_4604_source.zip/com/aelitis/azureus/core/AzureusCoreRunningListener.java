/**
 * 
 */
package com.aelitis.azureus.core;

/**
 * See {@link AzureusCoreFactory#addCoreRunningListener(AzureusCoreRunningListener)}
 * @author vuze
 *
 */
public interface AzureusCoreRunningListener {
	public void azureusCoreRunning(AzureusCore core);
}
